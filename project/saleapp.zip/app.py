from saleapp import main
main.app.run(debug=True, host='0.0.0.0')