# CongNghePhanMem_ChuyenBay
### Khách hàng: 
  - Những việc liên quan đến: 
    - Nhận lịch chuyến bay
    - Tra cứu chuyến bay
  - Những thông tin cần quản lý trong hệ thống: 
    - Thông tin chuyến bay
  - Những thông tin cần truy xuất từ hệ thống: 
    - Thông tin chuyến bay

  ### Nhân viên: 
  - Những việc liên quan đến: 
    -	Bán vé
    -	Ghi nhận đặt vé
    -	Tra cứu chuyến bay
    -	Lập báo cáo tháng
    -	Thay đổi quy định
  - Những thông tin cần quản lý trong hệ thống: 
    -	Thông tin chuyến bay
  - Những thông tin cần truy xuất từ hệ thống: 
    -	Thông tin chuyến bay


